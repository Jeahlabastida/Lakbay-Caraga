export type Category = "beach" | "falls" | "nature" | "cultural"

export type Destination = {
  id: string
  name: string
  province: string
  municipality: string
  category: Category
  rating: number
  image: string
  description: string
  longDescription: string
  bestTime: string
  activities: string[]
  gallery: string[]
  map: { x: number y: number }
}

const photos = {
  island:
    "https://images.unsplash.com/photo-1518509562904-e7ef99cdcc86?auto=format&fit=crop&w=1600&q=85",
  beach:
    "https://images.unsplash.com/photo-1695051702427-1c24ce3682e7?auto=format&fit=crop&w=1600&q=85",
  boats:
    "https://images.unsplash.com/photo-1519101236449-ac8098e16f15?auto=format&fit=crop&w=1600&q=85",
  water:
    "https://images.unsplash.com/photo-1547122891-8aae3f2a03dc?auto=format&fit=crop&w=1600&q=85",
  palms:
    "https://images.unsplash.com/photo-1531951286638-d1b6cdae30c9?auto=format&fit=crop&w=1600&q=85",
  falls:
    "https://images.unsplash.com/photo-1711371134657-682d220bec47?auto=format&fit=crop&w=1600&q=85",
  fallsTwo:
    "https://images.unsplash.com/photo-1495448715410-80ec866d8375?auto=format&fit=crop&w=1600&q=85",
  river:
    "https://images.unsplash.com/photo-1767167649218-f8b03f66d28c?auto=format&fit=crop&w=1600&q=85",
  pool: "https://images.unsplash.com/photo-1767167648861-00bbc5c5cf43?auto=format&fit=crop&w=1600&q=85",
  lake: "https://images.unsplash.com/photo-1644662149657-9bc6de1812ec?auto=format&fit=crop&w=1600&q=85",
  mountain:
    "https://images.unsplash.com/photo-1598175703471-4d4d0f88f6f3?auto=format&fit=crop&w=1600&q=85",
  lagoon:
    "https://images.unsplash.com/photo-1758782551890-0f47a570859c?auto=format&fit=crop&w=1600&q=85",
}

export const destinations: Destination[] = [
  {
    id: "enchanted-river",
    name: "Enchanted River",
    province: "Surigao del Sur",
    municipality: "Hinatuan",
    category: "nature",
    rating: 4.9,
    image: photos.pool,
    description:
      "A crystal-blue spring river hidden beneath a canopy of lush forest.",
    longDescription:
      "Hinatuan Enchanted River is known for its astonishing sapphire water, quiet forest setting, and mysterious depth. Follow the boardwalk to the main lagoon, watch the midday fish feeding, then explore nearby coves by boat with a local guide.",
    bestTime: "March to May, early morning",
    activities: ["Swimming", "Boat tour", "Fish feeding", "Photography"],
    gallery: [photos.river, photos.pool, photos.water],
    map: { x: 68, y: 68 },
  },
  {
    id: "tinuy-an-falls",
    name: "Tinuy-an Falls",
    province: "Surigao del Sur",
    municipality: "Bislig",
    category: "falls",
    rating: 4.8,
    image: photos.falls,
    description:
      "A broad three-tier cascade often called the Niagara Falls of the Philippines.",
    longDescription:
      "Tinuy-an Falls spreads across a dramatic forested cliff in Bislig. Fine mist catches the morning light, while bamboo rafts bring visitors close to the powerful curtain of water.",
    bestTime: "June to November, before 9 AM",
    activities: ["Bamboo rafting", "Swimming", "Nature walks", "Photography"],
    gallery: [photos.falls, photos.fallsTwo, photos.river],
    map: { x: 73, y: 82 },
  },
  {
    id: "lake-mainit",
    name: "Lake Mainit",
    province: "Surigao del Norte",
    municipality: "Mainit",
    category: "nature",
    rating: 4.7,
    image: photos.lake,
    description:
      "A serene mountain lake shared by two provinces and rich in birdlife.",
    longDescription:
      "One of the Philippines’ largest lakes, Lake Mainit is framed by forested ridges and quiet lakeside communities. Slow mornings here are made for paddling, birdwatching, and meeting local fishers.",
    bestTime: "December to May, sunrise",
    activities: [
      "Kayaking",
      "Birdwatching",
      "Fishing village tour",
      "Sunrise viewing",
    ],
    gallery: [photos.lake, photos.lagoon, photos.mountain],
    map: { x: 47, y: 34 },
  },
  {
    id: "siargao-island",
    name: "Siargao Island",
    province: "Surigao del Norte",
    municipality: "General Luna",
    category: "beach",
    rating: 4.9,
    image: photos.palms,
    description:
      "World-class surf, palm-lined roads, tidal pools, and easy island days.",
    longDescription:
      "Siargao pairs celebrated surf breaks with mangrove forests, rock pools, and a warm creative community. Beyond Cloud 9, island-hop to white sandbars or take a slow ride through coconut country.",
    bestTime: "March to October",
    activities: ["Surfing", "Island hopping", "Tidal pools", "Cycling"],
    gallery: [photos.palms, photos.island, photos.boats],
    map: { x: 82, y: 24 },
  },
  {
    id: "britania-islands",
    name: "Britania Group of Islands",
    province: "Surigao del Sur",
    municipality: "San Agustin",
    category: "beach",
    rating: 4.8,
    image: photos.island,
    description:
      "A scattering of white-sand islets set in clear turquoise water.",
    longDescription:
      "Britania’s compact island cluster makes for an unhurried day of swimming, snorkeling, and picnic stops. Local boat operators connect the most scenic sandbars and limestone-edged coves.",
    bestTime: "March to May",
    activities: ["Island hopping", "Snorkeling", "Beach picnic", "Swimming"],
    gallery: [photos.island, photos.beach, photos.boats],
    map: { x: 67, y: 61 },
  },
  {
    id: "mount-hilong-hilong",
    name: "Mount Hilong-hilong",
    province: "Agusan del Norte",
    municipality: "Cabadbaran",
    category: "nature",
    rating: 4.6,
    image: photos.mountain,
    description:
      "Caraga’s highest peak, wrapped in mossy forest and mountain mist.",
    longDescription:
      "Mount Hilong-hilong rewards prepared hikers with biodiverse forest, cool ridge camps, and broad views across northeastern Mindanao. Climbs require coordination with accredited local guides.",
    bestTime: "February to April",
    activities: ["Trekking", "Camping", "Birdwatching", "Forest bathing"],
    gallery: [photos.mountain, photos.lake, photos.lagoon],
    map: { x: 36, y: 43 },
  },
  {
    id: "laswitan-lagoon",
    name: "Laswitan Lagoon",
    province: "Surigao del Sur",
    municipality: "Cortes",
    category: "nature",
    rating: 4.7,
    image: photos.water,
    description:
      "A rugged coastal lagoon where ocean spray falls like a saltwater cascade.",
    longDescription:
      "Laswitan is a dramatic meeting of rock and Pacific swell. During the right season, waves crest over the limestone wall and pour into the natural lagoon beyond.",
    bestTime: "November to March",
    activities: ["Coastal walk", "Swimming", "Photography", "Picnic"],
    gallery: [photos.water, photos.beach, photos.island],
    map: { x: 72, y: 52 },
  },
  {
    id: "balangay-shrine",
    name: "Balangay Shrine",
    province: "Agusan del Norte",
    municipality: "Butuan City",
    category: "cultural",
    rating: 4.6,
    image: photos.boats,
    description:
      "Discover the ancient boats that reveal Caraga’s seafaring heritage.",
    longDescription:
      "The Balangay Shrine preserves the story of early wooden watercraft excavated in Butuan. It offers a vivid introduction to the region’s trade, craftsmanship, and maritime identity.",
    bestTime: "Year-round, weekday mornings",
    activities: [
      "Museum visit",
      "Heritage walk",
      "Local history",
      "Photography",
    ],
    gallery: [photos.boats, photos.river, photos.lake],
    map: { x: 28, y: 58 },
  },
  {
    id: "sohoton-cove",
    name: "Sohoton Cove",
    province: "Surigao del Norte",
    municipality: "Socorro",
    category: "nature",
    rating: 4.8,
    image: photos.lagoon,
    description:
      "A maze of jade lagoons, limestone islets, caves, and quiet coves.",
    longDescription:
      "Sohoton Cove is a protected seascape of forested limestone, glassy channels, and hidden caves. Local boat guides time each visit with the tides and share the stories behind this remarkable island sanctuary.",
    bestTime: "March to September",
    activities: ["Cove cruise", "Cave visit", "Kayaking", "Wildlife watching"],
    gallery: [photos.lagoon, photos.island, photos.water],
    map: { x: 85, y: 39 },
  },
  {
    id: "sugba-lagoon",
    name: "Sugba Lagoon",
    province: "Surigao del Norte",
    municipality: "Del Carmen",
    category: "nature",
    rating: 4.8,
    image: photos.lagoon,
    description:
      "A calm emerald lagoon tucked inside Del Carmen’s mangrove reserve.",
    longDescription:
      "Sugba Lagoon opens beyond one of the Philippines’ largest mangrove forests. Its sheltered water is ideal for paddling, swimming, and an unhurried lunch at the floating pavilion.",
    bestTime: "March to October",
    activities: ["Paddleboarding", "Kayaking", "Swimming", "Mangrove cruise"],
    gallery: [photos.lagoon, photos.water, photos.palms],
    map: { x: 76, y: 21 },
  },
  {
    id: "naked-island",
    name: "Naked Island",
    province: "Surigao del Norte",
    municipality: "General Luna",
    category: "beach",
    rating: 4.7,
    image: photos.beach,
    description:
      "An exposed white sandbar surrounded by clear, shifting shades of blue.",
    longDescription:
      "Naked Island is a clean ribbon of sand with no trees or structures—just sea, sky, and wide-open views. It is a classic stop on the three-island loop from General Luna.",
    bestTime: "March to May, early morning",
    activities: ["Swimming", "Sunbathing", "Island hopping", "Photography"],
    gallery: [photos.beach, photos.boats, photos.island],
    map: { x: 89, y: 31 },
  },
  {
    id: "magpupungko-rock-pools",
    name: "Magpupungko Rock Pools",
    province: "Surigao del Norte",
    municipality: "Pilar",
    category: "nature",
    rating: 4.8,
    image: photos.water,
    description:
      "Natural tidal pools revealed by low tide along a dramatic reef shelf.",
    longDescription:
      "At low tide, Magpupungko’s reef becomes a playground of clear pools and sculpted rock. Tide timing is essential, and local guides can point out the safest places to swim and explore.",
    bestTime: "Low tide, March to October",
    activities: ["Tide pooling", "Swimming", "Rock walk", "Photography"],
    gallery: [photos.water, photos.pool, photos.beach],
    map: { x: 87, y: 24 },
  },
  {
    id: "cloud-9-boardwalk",
    name: "Cloud 9 Boardwalk",
    province: "Surigao del Norte",
    municipality: "General Luna",
    category: "beach",
    rating: 4.7,
    image: photos.palms,
    description:
      "Siargao’s iconic surf lookout facing one of the world’s famous reef breaks.",
    longDescription:
      "The Cloud 9 Boardwalk stretches over the reef to a viewing tower where surfers, families, and sunset watchers gather. Come early for a calm walk or during swell season for the full spectacle.",
    bestTime: "September to November",
    activities: ["Surf watching", "Surfing", "Sunrise walk", "Photography"],
    gallery: [photos.palms, photos.water, photos.beach],
    map: { x: 91, y: 27 },
  },
  {
    id: "guyam-island",
    name: "Guyam Island",
    province: "Surigao del Norte",
    municipality: "General Luna",
    category: "beach",
    rating: 4.6,
    image: photos.island,
    description:
      "A tiny palm-covered island ringed by white sand and shallow reef.",
    longDescription:
      "Guyam Island is small enough to circle on foot and relaxed enough to stay awhile. Palms shade the center while gentle shallows and reef edges frame an easy island-hopping stop.",
    bestTime: "March to October",
    activities: ["Island walk", "Swimming", "Snorkeling", "Beach picnic"],
    gallery: [photos.island, photos.palms, photos.boats],
    map: { x: 92, y: 35 },
  },
  {
    id: "day-asan-floating-village",
    name: "Day-asan Floating Village",
    province: "Surigao del Norte",
    municipality: "Surigao City",
    category: "cultural",
    rating: 4.5,
    image: photos.boats,
    description:
      "A water-based community shaped by mangroves, fishing, and daily tides.",
    longDescription:
      "Day-asan offers a respectful look at a community built around tidal channels and mangrove forests. Community-led boat visits share local livelihoods, food traditions, and environmental knowledge.",
    bestTime: "December to May, morning",
    activities: ["Community tour", "Boat ride", "Mangrove visit", "Local food"],
    gallery: [photos.boats, photos.river, photos.palms],
    map: { x: 54, y: 18 },
  },
  {
    id: "mabua-pebble-beach",
    name: "Mabua Pebble Beach",
    province: "Surigao del Sur",
    municipality: "Tandag",
    category: "beach",
    rating: 4.5,
    image: photos.beach,
    description:
      "A distinctive shoreline of smooth stones, clear water, and open horizons.",
    longDescription:
      "Mabua trades powdery sand for a textured sweep of polished pebbles. The sound of the tide rolling through the stones and the broad coastal sunset make it a memorable slow-travel stop.",
    bestTime: "December to May, late afternoon",
    activities: ["Beach walk", "Swimming", "Sunset viewing", "Photography"],
    gallery: [photos.beach, photos.water, photos.island],
    map: { x: 68, y: 47 },
  },
  {
    id: "cagwait-white-beach",
    name: "Cagwait White Beach",
    province: "Surigao del Sur",
    municipality: "Cagwait",
    category: "beach",
    rating: 4.6,
    image: photos.beach,
    description:
      "A broad crescent of pale sand and calm water known as Caraga’s Waikiki.",
    longDescription:
      "Cagwait White Beach curves around a peaceful bay with soft sand, shallow water, and plenty of room to settle in. It is especially inviting in the quiet hours just after sunrise.",
    bestTime: "March to May",
    activities: ["Swimming", "Beach walk", "Paddling", "Picnic"],
    gallery: [photos.beach, photos.island, photos.water],
    map: { x: 70, y: 57 },
  },
  {
    id: "agusan-marsh",
    name: "Agusan Marsh Wildlife Sanctuary",
    province: "Agusan del Sur",
    municipality: "Bunawan",
    category: "nature",
    rating: 4.7,
    image: photos.river,
    description:
      "A vast wetland sanctuary of flooded forest, lakes, birds, and floating homes.",
    longDescription:
      "Agusan Marsh is one of the country’s most important freshwater wetlands. Community-guided boat trips reveal flooded forests, bird habitat, and a way of life closely attuned to the rise and fall of the water.",
    bestTime: "December to March",
    activities: [
      "Birdwatching",
      "Boat safari",
      "Community visit",
      "Photography",
    ],
    gallery: [photos.river, photos.lake, photos.boats],
    map: { x: 31, y: 78 },
  },
  {
    id: "butuan-national-museum",
    name: "Butuan National Museum",
    province: "Agusan del Norte",
    municipality: "Butuan City",
    category: "cultural",
    rating: 4.5,
    image: photos.boats,
    description:
      "Archaeology, goldwork, and maritime history gathered in one essential stop.",
    longDescription:
      "The Butuan National Museum traces the region’s deep history through archaeological finds, trade objects, and exhibits on the ancient balangay boats. It is the ideal context-setting stop for a wider Caraga journey.",
    bestTime: "Year-round, weekday mornings",
    activities: [
      "Museum visit",
      "History tour",
      "Artifact viewing",
      "Research",
    ],
    gallery: [photos.boats, photos.river, photos.lake],
    map: { x: 25, y: 60 },
  },
  {
    id: "magallanes-marker",
    name: "Magallanes Marker",
    province: "Agusan del Norte",
    municipality: "Butuan City",
    category: "cultural",
    rating: 4.4,
    image: photos.river,
    description:
      "A riverside historical marker recalling Butuan’s place in early voyages.",
    longDescription:
      "The Magallanes Marker stands near the Agusan River as a compact heritage stop. Pair it with Butuan’s museums and balangay sites for a fuller view of the city’s long maritime story.",
    bestTime: "Year-round, late afternoon",
    activities: [
      "Heritage walk",
      "River viewing",
      "History tour",
      "Photography",
    ],
    gallery: [photos.river, photos.boats, photos.lake],
    map: { x: 22, y: 63 },
  },
]

export const categoryLabels: Record<Category, string> = {
  beach: "Beach",
  falls: "Falls",
  nature: "Nature",
  cultural: "Cultural",
}

export const provinces = [
  "All provinces",
  "Agusan del Norte",
  "Agusan del Sur",
  "Surigao del Norte",
  "Surigao del Sur",
]
