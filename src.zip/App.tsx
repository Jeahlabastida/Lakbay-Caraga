import {
  createContext,
  FormEvent,
  ReactNode,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react"
import {
  Category,
  Destination,
  categoryLabels,
  destinations,
  provinces,
} from "./data"

type ScreenId = "home" | "destinations" | "details" | "map" | "itinerary" | "search" | "about" | "contact" | "signup" | "login" | "bookings"

type IconName = "arrow" | "calendar" | "check" | "chevron" | "clock" | "compass" | "facebook" | "instagram" | "mail" | "map" | "menu" | "phone" | "pin" | "search" | "star" | "trash"

type ButtonProps = {
  children: ReactNode
  className?: string
  onClick?: () => void
  type?: "button" | "submit"
  variant?: "primary" | "secondary" | "ghost" | "light"
  ariaLabel?: string
  disabled?: boolean
}

type ItineraryItem = {
  destinationId: string
  day: number
  time: string
  duration: string
}

type BookingStatus = "Pending" | "Confirmed" | "Completed" | "Cancelled"

type Booking = {
  id: string
  destinationId: string
  status: BookingStatus
  date: string
  guests: number
  requested: string
  note?: string
}

type AppContextValue = {
  isLoggedIn: boolean
  userName: string
  navigate: (screen: ScreenId) => void
  login: (name?: string) => void
  logout: () => void
  requestBooking: (
    destination: Destination,
    date: string,
    guests: number,
    note: string,
  ) => void
}

const AppContext = createContext<AppContextValue | null>(null)

function useAppContext() {
  const context = useContext(AppContext)
  if (!context) throw new Error("App context is unavailable")
  return context
}

const screenPaths: Record<Exclude<ScreenId, "details">, string> = {
  home: "#/home",
  destinations: "#/destinations",
  map: "#/map",
  itinerary: "#/itinerary",
  search: "#/search",
  about: "#/about",
  contact: "#/contact",
  signup: "#/signup",
  login: "#/login",
  bookings: "#/bookings",
}

const navItems: {
  label: string
  screen: Exclude<ScreenId, "details" | "search">
}[] = [
  { label: "Home", screen: "home" },
  { label: "Destinations", screen: "destinations" },
  { label: "Map", screen: "map" },
  { label: "Itinerary", screen: "itinerary" },
  { label: "About", screen: "about" },
  { label: "Contact", screen: "contact" },
]

function Icon({
  name,
  className = "size-5",
}: {
  name: IconName
  className?: string
}) {
  const paths: Record<IconName, ReactNode> = {
    arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    calendar: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="2" />
        <path d="M16 3v4M8 3v4M3 10h18" />
      </>
    ),
    check: <path d="m5 12 4 4L19 6" />,
    chevron: <path d="m9 18 6-6-6-6" />,
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    compass: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="m15.5 8.5-2.2 4.8-4.8 2.2 2.2-4.8 4.8-2.2Z" />
      </>
    ),
    facebook: (
      <path d="M14 8h3V4h-3c-3 0-5 2-5 5v3H6v4h3v6h4v-6h3l1-4h-4V9c0-.7.3-1 1-1Z" />
    ),
    instagram: (
      <>
        <rect x="3" y="3" width="18" height="18" rx="5" />
        <circle cx="12" cy="12" r="4" />
        <path d="M17.5 6.5h.01" />
      </>
    ),
    mail: (
      <>
        <rect x="3" y="5" width="18" height="14" rx="2" />
        <path d="m4 7 8 6 8-6" />
      </>
    ),
    map: (
      <>
        <path d="m3 6 6-3 6 3 6-3v15l-6 3-6-3-6 3V6Z" />
        <path d="M9 3v15M15 6v15" />
      </>
    ),
    menu: <path d="M4 7h16M4 12h16M4 17h16" />,
    phone: (
      <path d="M7 3H4a1 1 0 0 0-1 1c0 9.4 7.6 17 17 17a1 1 0 0 0 1-1v-3l-4-1-2 2c-4-1.5-7.5-5-9-9l2-2-1-4Z" />
    ),
    pin: (
      <>
        <path d="M20 10c0 5-8 11-8 11S4 15 4 10a8 8 0 1 1 16 0Z" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    search: (
      <>
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-4-4" />
      </>
    ),
    star: (
      <path d="m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2-5.6-3-5.6 3 1.1-6.2L3 9.6l6.2-.9L12 3Z" />
    ),
    trash: (
      <>
        <path d="M4 7h16M9 7V4h6v3M7 7l1 14h8l1-14M10 11v6M14 11v6" />
      </>
    ),
  }

  return (
    <svg
      aria-hidden="true"
      className={className}
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {paths[name]}
    </svg>
  )
}

function Button({
  children,
  className = "",
  onClick,
  type = "button",
  variant = "primary",
  ariaLabel,
  disabled,
}: ButtonProps) {
  const styles = {
    primary: "bg-accent text-ink hover:bg-accent-strong shadow-sm",
    secondary: "bg-primary text-white hover:bg-primary-deep shadow-sm",
    ghost: "bg-transparent text-primary hover:bg-primary-soft",
    light: "bg-white text-primary hover:bg-sand shadow-sm",
  }
  return (
    <button
      type={type}
      aria-label={ariaLabel}
      disabled={disabled}
      onClick={onClick}
      className={`inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-bold transition duration-200 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:cursor-not-allowed disabled:opacity-50 ${styles[variant]} ${className}`}
    >
      {children}
    </button>
  )
}

function Heading({
  level = 2,
  children,
  className = "",
}: {
  level?: 1 | 2 | 3 | 4
  children: ReactNode
  className?: string
}) {
  const Tag = `h${level}` as "h1" | "h2" | "h3" | "h4"
  return (
    <Tag className={`font-extrabold tracking-tight text-balance ${className}`}>
      {children}
    </Tag>
  )
}

function Input({
  value,
  onChange,
  placeholder,
  type = "text",
  name,
  ariaLabel,
  className = "",
  min,
  max,
}: {
  value: string
  onChange: (value: string) => void
  placeholder?: string
  type?: string
  name?: string
  ariaLabel: string
  className?: string
  min?: string
  max?: string
}) {
  return (
    <input
      type={type}
      name={name}
      value={value}
      aria-label={ariaLabel}
      placeholder={placeholder}
      min={min}
      max={max}
      onChange={(event) => onChange(event.target.value)}
      className={`w-full rounded-2xl border border-line bg-white px-4 py-3.5 text-sm text-ink outline-none transition placeholder:text-muted focus:border-primary focus:ring-4 focus:ring-primary/10 ${className}`}
    />
  )
}

function BookingPanel({ destination }: { destination: Destination }) {
  const { isLoggedIn, navigate, requestBooking } = useAppContext()
  const [date, setDate] = useState("2026-05-16")
  const [guests, setGuests] = useState("2")
  const [notes, setNotes] = useState("")

  const submit = (event: FormEvent) => {
    event.preventDefault()
    requestBooking(destination, date, Number(guests), notes)
  }

  return (
    <section className="mx-auto max-w-7xl px-6 pb-16">
      <div className="grid overflow-hidden rounded-[2rem] border border-line bg-white shadow-card lg:grid-cols-[0.72fr_1.28fr]">
        <div className="relative overflow-hidden bg-primary p-8 text-white md:p-10">
          <div className="absolute inset-0 topographic opacity-10" />
          <div className="relative">
            <Badge dark>Book your visit</Badge>
            <Heading level={2} className="mt-5 text-3xl">
              Reserve a day at {destination.name}.
            </Heading>
            <p className="mt-4 max-w-md leading-7 text-white/65">
              Send a request to the local tourism desk. You can track every
              update from My bookings.
            </p>
          </div>
        </div>
        <div className="p-8 md:p-10">
          {isLoggedIn ? (
            <form onSubmit={submit}>
              <Heading level={3} className="text-2xl text-ink">
                Request a booking
              </Heading>
              <div className="mt-6 grid gap-5 sm:grid-cols-2">
                <label className="text-sm font-bold text-ink">
                  Date of visit
                  <Input
                    type="date"
                    value={date}
                    onChange={setDate}
                    ariaLabel="Date of visit"
                    className="mt-2 font-normal"
                  />
                </label>
                <label className="text-sm font-bold text-ink">
                  Guests
                  <Input
                    type="number"
                    min="1"
                    max="20"
                    value={guests}
                    onChange={setGuests}
                    ariaLabel="Number of guests"
                    className="mt-2 font-normal"
                  />
                </label>
              </div>
              <label className="mt-5 block text-sm font-bold text-ink">
                Notes <span className="font-normal text-muted">(optional)</span>
                <textarea
                  value={notes}
                  onChange={(event) => setNotes(event.target.value)}
                  aria-label="Booking notes"
                  rows={3}
                  placeholder="Accessibility needs, preferred arrival time, or questions"
                  className="mt-2 w-full resize-none rounded-2xl border border-line bg-white px-4 py-3.5 font-normal text-ink outline-none transition placeholder:text-muted focus:border-primary focus:ring-4 focus:ring-primary/10"
                />
              </label>
              <Button type="submit" className="mt-6">
                Request booking
                <Icon name="arrow" className="size-4" />
              </Button>
            </form>
          ) : (
            <div className="flex min-h-64 flex-col justify-center">
              <Heading level={3} className="text-2xl text-ink">
                Log in to book this place
              </Heading>
              <p className="mt-3 max-w-xl leading-7 text-muted">
                Create a free account to request a date and follow its status
                from pending to confirmed.
              </p>
              <div className="mt-6 flex flex-wrap gap-3">
                <Button variant="secondary" onClick={() => navigate("login")}>
                  Log in
                </Button>
                <Button onClick={() => navigate("signup")}>
                  Create an account
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  )
}

function Select({
  value,
  onChange,
  children,
  ariaLabel,
  className = "",
}: {
  value: string
  onChange: (value: string) => void
  children: ReactNode
  ariaLabel: string
  className?: string
}) {
  return (
    <select
      value={value}
      onChange={(event) => onChange(event.target.value)}
      aria-label={ariaLabel}
      className={`rounded-full border border-line bg-white px-4 py-3 text-sm font-semibold text-ink outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 ${className}`}
    >
      {children}
    </select>
  )
}

function Badge({
  children,
  dark = false,
}: {
  children: ReactNode
  dark?: boolean
}) {
  return (
    <span
      className={`inline-flex rounded-full px-3 py-1 text-xs font-bold tracking-wide ${
        dark ? "bg-white/15 text-white" : "bg-primary-soft text-primary"
      }`}
    >
      {children}
    </span>
  )
}

function Rating({ value }: { value: number }) {
  return (
    <span className="inline-flex items-center gap-1 text-sm font-bold text-ink">
      <Icon name="star" className="size-4 fill-accent text-accent-strong" />
      {value.toFixed(1)}
    </span>
  )
}

function SectionHeading({
  eyebrow,
  title,
  copy,
  inverse = false,
}: {
  eyebrow: string
  title: string
  copy?: string
  inverse?: boolean
}) {
  return (
    <div className="max-w-2xl">
      <p
        className={`mb-3 text-xs font-extrabold uppercase tracking-[0.18em] ${
          inverse ? "text-accent" : "text-primary"
        }`}
      >
        {eyebrow}
      </p>
      <Heading
        level={2}
        className={`text-3xl md:text-4xl ${
          inverse ? "text-white" : "text-ink"
        }`}
      >
        {title}
      </Heading>
      {copy && (
        <p
          className={`mt-4 leading-7 ${
            inverse ? "text-white/70" : "text-muted"
          }`}
        >
          {copy}
        </p>
      )}
    </div>
  )
}

function DestinationCard({
  destination,
  onOpen,
  compact = false,
}: {
  destination: Destination
  onOpen: (destination: Destination) => void
  compact?: boolean
}) {
  return (
    <article
      onClick={() => onOpen(destination)}
      className="group cursor-pointer overflow-hidden rounded-3xl border border-line bg-white shadow-card transition duration-300 hover:-translate-y-1 hover:shadow-card-hover"
    >
      <div className={`relative overflow-hidden ${compact ? "h-44" : "h-52"}`}>
        <img
          src={destination.image}
          alt={`${destination.name} landscape`}
          className="size-full object-cover transition duration-500 group-hover:scale-105"
        />
        <div className="absolute left-4 top-4">
          <Badge dark>{categoryLabels[destination.category]}</Badge>
        </div>
      </div>
      <div className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div>
            <Heading level={3} className="text-xl text-ink">
              {destination.name}
            </Heading>
            <p className="mt-1 flex items-center gap-1.5 text-sm text-muted">
              <Icon name="pin" className="size-4 text-primary" />
              {destination.municipality}, {destination.province}
            </p>
          </div>
          <Rating value={destination.rating} />
        </div>
        {!compact && (
          <p className="mt-4 line-clamp-2 text-sm leading-6 text-muted">
            {destination.description}
          </p>
        )}
        <div className="mt-5 flex items-center gap-2 text-sm font-bold text-primary">
          View destination
          <Icon
            name="arrow"
            className="size-4 transition group-hover:translate-x-1"
          />
        </div>
      </div>
    </article>
  )
}

function Logo({ onClick }: { onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="group flex items-center gap-3 rounded-xl focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-accent"
    >
      <span className="relative grid size-10 place-items-center overflow-hidden rounded-full bg-accent text-primary">
        <span className="absolute -bottom-1 h-4 w-12 rounded-[50%] bg-primary" />
        <Icon name="compass" className="relative size-5" />
      </span>
      <span className="text-left text-lg font-extrabold leading-tight tracking-tight text-white">
        Lakbay
        <span className="block text-xs font-bold uppercase tracking-[0.18em] text-accent">
          Caraga
        </span>
      </span>
    </button>
  )
}

function NavBar({
  active,
  itineraryCount,
  navigate,
}: {
  active: ScreenId
  itineraryCount: number
  navigate: (screen: ScreenId) => void
}) {
  const [open, setOpen] = useState(false)
  const { isLoggedIn, logout } = useAppContext()
  const activeParent =
    active === "details" || active === "search" ? "destinations" : active
  return (
    <header className="sticky top-0 z-50 bg-primary text-white shadow-lg shadow-primary-deep/10">
      <div className="mx-auto flex h-20 max-w-screen-2xl items-center justify-between px-6 lg:px-10">
        <Logo onClick={() => navigate("home")} />
        <nav
          className="hidden items-center gap-1 lg:flex"
          aria-label="Main navigation"
        >
          {navItems.map((item) => (
            <Button
              key={item.screen}
              variant="ghost"
              onClick={() => navigate(item.screen)}
              className={`relative !px-4 !py-2.5 ${
                activeParent === item.screen
                  ? "!bg-white/10 !text-white"
                  : "!text-white/75 hover:!bg-white/10 hover:!text-white"
              }`}
            >
              {item.label}
              {item.screen === "itinerary" && itineraryCount > 0 && (
                <span className="grid size-5 place-items-center rounded-full bg-accent text-[0.65rem] text-ink">
                  {itineraryCount}
                </span>
              )}
              {activeParent === item.screen && (
                <span className="absolute -bottom-2 h-0.5 w-5 rounded-full bg-accent" />
              )}
            </Button>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Button
            variant="ghost"
            ariaLabel="Search destinations"
            onClick={() => navigate("search")}
            className="!size-11 !p-0 !text-white hover:!bg-white/10"
          >
            <Icon name="search" />
          </Button>
          <div className="hidden items-center gap-2 xl:flex">
            {isLoggedIn ? (
              <>
                <Button
                  variant="ghost"
                  onClick={() => navigate("bookings")}
                  className="!text-white hover:!bg-white/10"
                >
                  My bookings
                </Button>
                <Button variant="light" onClick={logout}>
                  Log out
                </Button>
              </>
            ) : (
              <>
                <Button
                  variant="ghost"
                  onClick={() => navigate("login")}
                  className="!text-white hover:!bg-white/10"
                >
                  Log in
                </Button>
                <Button onClick={() => navigate("signup")}>Sign up</Button>
              </>
            )}
          </div>
          <Button
            variant="ghost"
            ariaLabel="Open navigation"
            onClick={() => setOpen(!open)}
            className="!size-11 !p-0 !text-white hover:!bg-white/10 xl:!hidden"
          >
            <Icon name="menu" />
          </Button>
        </div>
      </div>
      {open && (
        <nav
          className="grid gap-1 border-t border-white/10 px-5 py-4 xl:hidden"
          aria-label="Mobile navigation"
        >
          <div className="grid gap-1 lg:hidden">
            {navItems.map((item) => (
              <Button
                key={item.screen}
                variant="ghost"
                onClick={() => {
                  navigate(item.screen)
                  setOpen(false)
                }}
                className="!justify-start !text-white hover:!bg-white/10"
              >
                {item.label}
              </Button>
            ))}
          </div>
          <div className="my-2 border-t border-white/10" />
          {isLoggedIn ? (
            <>
              <Button
                variant="ghost"
                onClick={() => {
                  navigate("bookings")
                  setOpen(false)
                }}
                className="!justify-start !text-white hover:!bg-white/10"
              >
                My bookings
              </Button>
              <Button
                variant="light"
                onClick={logout}
                className="!justify-start"
              >
                Log out
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="ghost"
                onClick={() => {
                  navigate("login")
                  setOpen(false)
                }}
                className="!justify-start !text-white hover:!bg-white/10"
              >
                Log in
              </Button>
              <Button
                onClick={() => {
                  navigate("signup")
                  setOpen(false)
                }}
                className="!justify-start"
              >
                Sign up
              </Button>
            </>
          )}
        </nav>
      )}
    </header>
  )
}

function Footer({ navigate }: { navigate: (screen: ScreenId) => void }) {
  return (
    <footer className="bg-primary-deep px-6 py-10 text-white">
      <div className="mx-auto flex max-w-7xl flex-col justify-between gap-7 md:flex-row md:items-center">
        <div>
          <p className="text-lg font-extrabold">Lakbay Caraga</p>
          <p className="mt-1 text-sm text-white/60">
            Travel deeper. Tread lighter.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="ghost"
            onClick={() => navigate("about")}
            className="!text-white/70 hover:!bg-white/10 hover:!text-white"
          >
            Our story
          </Button>
          <Button
            variant="ghost"
            onClick={() => navigate("contact")}
            className="!text-white/70 hover:!bg-white/10 hover:!text-white"
          >
            Contact
          </Button>
        </div>
        <p className="text-xs text-white/45">Prototype imagery via Unsplash</p>
      </div>
    </footer>
  )
}

function ScreenShell({
  children,
  active,
  itineraryCount,
  navigate,
}: {
  children: ReactNode
  active: ScreenId
  itineraryCount: number
  navigate: (screen: ScreenId) => void
}) {
  return (
    <div className="min-h-screen bg-sand text-ink">
      <NavBar
        active={active}
        itineraryCount={itineraryCount}
        navigate={navigate}
      />
      <main className="screen-enter min-h-[calc(100vh-5rem)]">{children}</main>
      <Footer navigate={navigate} />
    </div>
  )
}

function HomeScreen({
  navigate,
  openDetails,
  itineraryCount,
  searchQuery,
  setSearchQuery,
}: {
  navigate: (screen: ScreenId) => void
  openDetails: (destination: Destination) => void
  itineraryCount: number
  searchQuery: string
  setSearchQuery: (value: string) => void
}) {
  const submitSearch = (event: FormEvent) => {
    event.preventDefault()
    navigate("search")
  }
  return (
    <ScreenShell
      active="home"
      itineraryCount={itineraryCount}
      navigate={navigate}
    >
      <section className="relative min-h-[660px] overflow-hidden bg-primary">
        <img
          src={destinations[3].image}
          alt="A tropical Caraga island landscape"
          className="absolute inset-0 size-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary-deep via-primary/85 to-primary/15" />
        <div className="absolute inset-0 topographic opacity-20" />
        <div className="relative mx-auto flex min-h-[660px] max-w-7xl items-center px-6 py-20">
          <div className="max-w-3xl">
            <Badge dark>Discover northeastern Mindanao</Badge>
            <Heading
              level={1}
              className="mt-6 text-5xl leading-[1.03] text-white md:text-7xl"
            >
              Go where the
              <span className="block text-accent">stories flow.</span>
            </Heading>
            <p className="mt-6 max-w-xl text-lg leading-8 text-white/80">
              Chase waterfalls, cross turquoise rivers, and meet the communities
              that make Caraga unforgettable.
            </p>
            <form
              onSubmit={submitSearch}
              className="mt-9 flex max-w-2xl flex-col gap-3 rounded-3xl bg-white p-2 shadow-2xl sm:flex-row"
            >
              <div className="flex flex-1 items-center gap-3 px-3">
                <Icon name="search" className="size-5 shrink-0 text-primary" />
                <Input
                  value={searchQuery}
                  onChange={setSearchQuery}
                  ariaLabel="Search destinations"
                  placeholder="Where do you want to wander?"
                  className="!border-0 !px-0 focus:!ring-0"
                />
              </div>
              <Button type="submit" className="sm:min-w-36">
                Find a place
                <Icon name="arrow" className="size-4" />
              </Button>
            </form>
            <div className="mt-7 flex flex-wrap items-center gap-x-8 gap-y-3 text-sm text-white/70">
              {["5 provinces", "30+ local stories", "100% Caraga"].map(
                (item) => (
                  <span key={item} className="flex items-center gap-2">
                    <Icon name="check" className="size-4 text-accent" />
                    {item}
                  </span>
                ),
              )}
            </div>
            <Button
              onClick={() => navigate("destinations")}
              variant="light"
              className="mt-8"
            >
              Explore now
              <Icon name="arrow" className="size-4" />
            </Button>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-6 py-20">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <SectionHeading
            eyebrow="Featured escapes"
            title="A little wild. Entirely unforgettable."
            copy="Start with places locals return to—each with its own rhythm, flavor, and story."
          />
          <Button variant="ghost" onClick={() => navigate("destinations")}>
            See all destinations
            <Icon name="arrow" className="size-4" />
          </Button>
        </div>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {[destinations[3], destinations[0], destinations[1]].map(
            (destination) => (
              <DestinationCard
                key={destination.id}
                destination={destination}
                onOpen={openDetails}
              />
            ),
          )}
        </div>
      </section>

      <section className="mx-auto mb-20 grid max-w-7xl overflow-hidden rounded-[2rem] bg-primary lg:grid-cols-[1.1fr_0.9fr]">
        <div className="p-10 md:p-14">
          <Badge dark>Travel with care</Badge>
          <Heading level={2} className="mt-5 max-w-xl text-4xl text-white">
            Let every journey give something back.
          </Heading>
          <p className="mt-5 max-w-xl leading-7 text-white/70">
            Choose local guides, respect protected waters, and leave every trail
            better than you found it.
          </p>
          <Button
            variant="primary"
            onClick={() => navigate("about")}
            className="mt-8"
          >
            Our mission
          </Button>
        </div>
        <img
          src={destinations[2].image}
          alt="Lake Mainit and its mountain landscape"
          className="h-full min-h-80 w-full object-cover"
        />
      </section>
    </ScreenShell>
  )
}

function FilterControls({
  province,
  setProvince,
  category,
  setCategory,
  clear,
}: {
  province: string
  setProvince: (value: string) => void
  category: "all" | Category
  setCategory: (value: "all" | Category) => void
  clear: () => void
}) {
  return (
    <div className="flex flex-col gap-4 rounded-3xl border border-line bg-white p-4 shadow-card lg:flex-row lg:items-center lg:justify-between">
      <div className="flex flex-wrap gap-2">
        {(["all", "beach", "falls", "nature", "cultural"] as const).map(
          (item) => (
            <Button
              key={item}
              variant={category === item ? "secondary" : "ghost"}
              onClick={() => setCategory(item)}
              className="!px-4 !py-2.5"
            >
              {item === "all" ? "All places" : categoryLabels[item]}
            </Button>
          ),
        )}
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <Select
          value={province}
          onChange={setProvince}
          ariaLabel="Filter by province"
        >
          {provinces.map((item) => (
            <option key={item}>{item}</option>
          ))}
        </Select>
        <Button variant="ghost" onClick={clear} className="!px-3">
          Clear
        </Button>
      </div>
    </div>
  )
}

function EmptyState({ clear }: { clear: () => void }) {
  return (
    <div className="col-span-full rounded-3xl border border-dashed border-line bg-white px-6 py-20 text-center">
      <span className="mx-auto grid size-14 place-items-center rounded-full bg-primary-soft text-primary">
        <Icon name="compass" className="size-7" />
      </span>
      <Heading level={3} className="mt-5 text-2xl text-ink">
        No trails found here—yet.
      </Heading>
      <p className="mx-auto mt-3 max-w-md text-muted">
        Try another province or category to uncover more of Caraga.
      </p>
      <Button onClick={clear} className="mt-6">
        Clear filters
      </Button>
    </div>
  )
}

function DestinationsScreen({
  navigate,
  openDetails,
  itineraryCount,
}: {
  navigate: (screen: ScreenId) => void
  openDetails: (destination: Destination) => void
  itineraryCount: number
}) {
  const [province, setProvince] = useState("All provinces")
  const [category, setCategory] = useState<"all" | Category>("all")
  const filtered = destinations.filter(
    (destination) =>
      (province === "All provinces" || destination.province === province) &&
      (category === "all" || destination.category === category),
  )
  const clear = () => {
    setProvince("All provinces")
    setCategory("all")
  }
  return (
    <ScreenShell
      active="destinations"
      itineraryCount={itineraryCount}
      navigate={navigate}
    >
      <section className="bg-primary px-6 py-16 text-white">
        <div className="mx-auto max-w-7xl">
          <SectionHeading
            inverse
            eyebrow="Find your next story"
            title="Destinations worth the detour"
            copy="From Pacific surf to highland forest, explore Caraga one remarkable place at a time."
          />
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-6 py-12">
        <FilterControls
          province={province}
          setProvince={setProvince}
          category={category}
          setCategory={setCategory}
          clear={clear}
        />
        <div className="mt-8 flex items-center justify-between">
          <p className="text-sm font-semibold text-muted">
            Showing <span className="text-ink">{filtered.length}</span>{" "}
            destinations
          </p>
          <p className="hidden text-sm text-muted sm:block">
            Curated by travelers who call Caraga home
          </p>
        </div>
        <div className="mt-6 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filtered.length ? (
            filtered.map((destination) => (
              <DestinationCard
                key={destination.id}
                destination={destination}
                onOpen={openDetails}
                compact
              />
            ))
          ) : (
            <EmptyState clear={clear} />
          )}
        </div>
      </section>
    </ScreenShell>
  )
}

function DetailsScreen({
  destination,
  navigate,
  addToItinerary,
  itineraryCount,
  isSaved,
}: {
  destination: Destination
  navigate: (screen: ScreenId) => void
  addToItinerary: (destination: Destination) => void
  itineraryCount: number
  isSaved: boolean
}) {
  return (
    <ScreenShell
      active="details"
      itineraryCount={itineraryCount}
      navigate={navigate}
    >
      <section className="relative min-h-[570px] overflow-hidden bg-primary">
        <img
          src={destination.image}
          alt={destination.name}
          className="absolute inset-0 size-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-primary-deep via-primary/30 to-transparent" />
        <div className="relative mx-auto flex min-h-[570px] max-w-7xl items-end px-6 pb-12">
          <div className="w-full">
            <Button
              variant="light"
              onClick={() => navigate("destinations")}
              className="mb-6 !bg-white/15 !text-white backdrop-blur-md hover:!bg-white/25"
            >
              <span className="rotate-180">
                <Icon name="arrow" className="size-4" />
              </span>
              All destinations
            </Button>
            <div className="flex flex-col justify-between gap-7 lg:flex-row lg:items-end">
              <div>
                <Badge dark>{categoryLabels[destination.category]}</Badge>
                <Heading
                  level={1}
                  className="mt-4 text-5xl text-white md:text-6xl"
                >
                  {destination.name}
                </Heading>
                <p className="mt-4 flex items-center gap-2 text-lg text-white/80">
                  <Icon name="pin" />
                  {destination.municipality}, {destination.province}
                </p>
              </div>
              <div className="flex items-center gap-4 rounded-3xl bg-white/95 p-3 pl-5 shadow-xl backdrop-blur">
                <Rating value={destination.rating} />
                <Button onClick={() => addToItinerary(destination)}>
                  {isSaved ? "View itinerary" : "Add to itinerary"}
                  <Icon
                    name={isSaved ? "check" : "calendar"}
                    className="size-4"
                  />
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section className="mx-auto grid max-w-7xl gap-12 px-6 py-16 lg:grid-cols-[1.5fr_0.7fr]">
        <div>
          <SectionHeading
            eyebrow="The experience"
            title="Blue water, green silence."
          />
          <p className="mt-7 text-lg leading-8 text-muted">
            {destination.longDescription}
          </p>
          <div className="mt-10">
            <Heading level={3} className="text-2xl text-ink">
              What you can do
            </Heading>
            <div className="mt-5 flex flex-wrap gap-3">
              {destination.activities.map((activity) => (
                <span
                  key={activity}
                  className="rounded-full border border-line bg-white px-4 py-2.5 text-sm font-semibold text-ink"
                >
                  {activity}
                </span>
              ))}
            </div>
          </div>
        </div>
        <aside className="rounded-3xl bg-primary p-7 text-white shadow-card">
          <Heading level={3} className="text-xl">
            Know before you go
          </Heading>
          <div className="mt-6 space-y-6">
            {[
              ["Best time", destination.bestTime, "calendar" as IconName],
              ["Suggested stay", "Half to full day", "clock" as IconName],
              ["Meet-up point", destination.municipality, "pin" as IconName],
            ].map(([label, value, icon]) => (
              <div key={label as string} className="flex gap-3">
                <span className="grid size-10 shrink-0 place-items-center rounded-full bg-white/10 text-accent">
                  <Icon name={icon as IconName} className="size-5" />
                </span>
                <div>
                  <p className="text-xs font-bold uppercase tracking-wider text-white/50">
                    {label}
                  </p>
                  <p className="mt-1 text-sm font-semibold">{value}</p>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-7 rounded-2xl bg-white/10 p-4 text-sm leading-6 text-white/70">
            Bring refillable water, follow guide instructions, and keep soaps
            and sunscreen away from freshwater pools.
          </div>
        </aside>
      </section>
      <BookingPanel destination={destination} />
      <section className="mx-auto max-w-7xl px-6 pb-20">
        <Heading level={2} className="text-3xl text-ink">
          A glimpse of the journey
        </Heading>
        <div className="mt-7 grid h-[430px] gap-4 md:grid-cols-2">
          <img
            src={destination.gallery[0]}
            alt={`${destination.name} landscape view`}
            className="size-full rounded-3xl object-cover"
          />
          <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-1 lg:grid-cols-2">
            {destination.gallery.slice(1).map((image, index) => (
              <img
                key={image}
                src={image}
                alt={`${destination.name} travel view ${index + 2}`}
                className="size-full rounded-3xl object-cover"
              />
            ))}
          </div>
        </div>
      </section>
    </ScreenShell>
  )
}

function MapScreen({
  navigate,
  openDetails,
  itineraryCount,
}: {
  navigate: (screen: ScreenId) => void
  openDetails: (destination: Destination) => void
  itineraryCount: number
}) {
  const [selectedId, setSelectedId] = useState(destinations[0].id)
  const selected =
    destinations.find((item) => item.id === selectedId) ?? destinations[0]
  return (
    <ScreenShell
      active="map"
      itineraryCount={itineraryCount}
      navigate={navigate}
    >
      <section className="mx-auto max-w-screen-2xl px-6 py-12 lg:px-10">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <SectionHeading
            eyebrow="Explore the region"
            title="Your Caraga compass"
            copy="Select a pin or place to discover what waits along the road."
          />
          <div className="flex flex-wrap gap-4 text-xs font-bold uppercase tracking-wider text-muted">
            {(["beach", "falls", "nature", "cultural"] as Category[]).map(
              (item) => (
                <span key={item} className="flex items-center gap-2">
                  <span className={`size-2.5 rounded-full marker-${item}`} />
                  {categoryLabels[item]}
                </span>
              ),
            )}
          </div>
        </div>
        <div className="mt-9 grid min-h-[690px] overflow-hidden rounded-[2rem] border border-line bg-white shadow-card lg:grid-cols-[1fr_390px]">
          <div className="relative min-h-[560px] overflow-hidden bg-map">
            <div className="absolute inset-0 map-grid opacity-50" />
            <svg
              aria-hidden="true"
              viewBox="0 0 700 700"
              className="absolute inset-0 size-full p-14 text-primary/15"
            >
              <path
                fill="#88b9a7"
                stroke="#0B5563"
                strokeWidth="4"
                d="M312 46c67 22 103 75 112 130 52 19 110 70 113 126 3 48-34 71-25 124 8 49 54 86 28 140-27 56-120 92-193 69-65-21-86-82-126-120-37-35-89-57-95-111-6-55 49-85 67-130 17-43-4-95 22-143 21-39 55-72 97-85Z"
              />
              <path
                d="M245 175c80 24 154 68 223 130M185 356c107 10 220 62 303 132M330 80c-18 170-7 343 60 527"
                stroke="white"
                strokeWidth="3"
                strokeDasharray="8 10"
                fill="none"
                opacity=".65"
              />
            </svg>
            {destinations.map((destination) => (
              <button
                key={destination.id}
                onClick={() => setSelectedId(destination.id)}
                aria-label={`Select ${destination.name}`}
                className={`map-pin marker-${destination.category} ${
                  selectedId === destination.id ? "is-active" : ""
                }`}
                style={{
                  left: `${destination.map.x}%`,
                  top: `${destination.map.y}%`,
                }}
              >
                <Icon name="pin" className="size-5" />
              </button>
            ))}
            <div className="absolute bottom-6 left-6 right-6 overflow-hidden rounded-3xl bg-white/95 shadow-xl backdrop-blur md:right-auto md:w-[390px]">
              <img
                src={selected.image}
                alt={selected.name}
                className="h-32 w-full object-cover"
              />
              <div className="p-5">
                <div className="flex justify-between gap-3">
                  <div>
                    <Heading level={3} className="text-lg text-ink">
                      {selected.name}
                    </Heading>
                    <p className="mt-1 text-xs text-muted">
                      {selected.municipality}, {selected.province}
                    </p>
                  </div>
                  <Rating value={selected.rating} />
                </div>
                <Button
                  variant="ghost"
                  onClick={() => openDetails(selected)}
                  className="mt-3 !p-0"
                >
                  View details
                  <Icon name="arrow" className="size-4" />
                </Button>
              </div>
            </div>
          </div>
          <aside className="border-l border-line">
            <div className="border-b border-line p-6">
              <Heading level={3} className="text-xl text-ink">
                Places on the map
              </Heading>
              <p className="mt-1 text-sm text-muted">
                {destinations.length} curated stops
              </p>
            </div>
            <div className="max-h-[610px] overflow-y-auto p-3">
              {destinations.map((destination) => (
                <button
                  key={destination.id}
                  onClick={() => setSelectedId(destination.id)}
                  className={`flex w-full items-center gap-3 rounded-2xl p-3 text-left transition ${
                    selectedId === destination.id
                      ? "bg-primary-soft"
                      : "hover:bg-sand"
                  }`}
                >
                  <img
                    src={destination.image}
                    alt=""
                    className="size-14 rounded-xl object-cover"
                  />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate text-sm font-bold text-ink">
                      {destination.name}
                    </span>
                    <span className="mt-1 block text-xs text-muted">
                      {destination.province}
                    </span>
                  </span>
                  <Icon name="chevron" className="size-4 text-primary" />
                </button>
              ))}
            </div>
          </aside>
        </div>
      </section>
    </ScreenShell>
  )
}

function ItineraryScreen({
  navigate,
  itinerary,
  setItinerary,
}: {
  navigate: (screen: ScreenId) => void
  itinerary: ItineraryItem[]
  setItinerary: (items: ItineraryItem[]) => void
}) {
  const moveNext = (id: string) => {
    setItinerary(
      itinerary.map((item) =>
        item.destinationId === id
          ? { ...item, day: item.day === 3 ? 1 : item.day + 1 }
          : item,
      ),
    )
  }
  const remove = (id: string) =>
    setItinerary(itinerary.filter((item) => item.destinationId !== id))
  return (
    <ScreenShell
      active="itinerary"
      itineraryCount={itinerary.length}
      navigate={navigate}
    >
      <section className="bg-primary px-6 py-14 text-white">
        <div className="mx-auto flex max-w-7xl flex-col justify-between gap-8 md:flex-row md:items-end">
          <SectionHeading
            inverse
            eyebrow="Your saved journey"
            title="Three days, one wild coast."
          />
          <div className="flex flex-wrap gap-3">
            <Badge dark>May 16–19</Badge>
            <Badge dark>{itinerary.length} saved stops</Badge>
          </div>
        </div>
      </section>
      <section className="mx-auto grid max-w-7xl gap-8 px-6 py-12 lg:grid-cols-[1fr_320px]">
        <div>
          {itinerary.length ? (
            <div className="grid gap-5 md:grid-cols-3">
              {[1, 2, 3].map((day) => {
                const stops = itinerary.filter((item) => item.day === day)
                return (
                  <section
                    key={day}
                    className="rounded-3xl border border-line bg-white p-5 shadow-card"
                  >
                    <div className="flex items-center justify-between border-b border-line pb-4">
                      <div>
                        <p className="text-xs font-extrabold uppercase tracking-wider text-primary">
                          Day {day}
                        </p>
                        <Heading level={3} className="mt-1 text-lg text-ink">
                          {day === 1
                            ? "River country"
                            : day === 2
                              ? "Falls & forest"
                              : "Island rhythm"}
                        </Heading>
                      </div>
                      <span className="grid size-9 place-items-center rounded-full bg-primary-soft text-primary">
                        {stops.length}
                      </span>
                    </div>
                    <div className="mt-5 space-y-4">
                      {stops.length ? (
                        stops.map((item) => {
                          const destination = destinations.find(
                            (place) => place.id === item.destinationId,
                          )!
                          return (
                            <article
                              key={item.destinationId}
                              className="rounded-2xl bg-sand p-3"
                            >
                              <img
                                src={destination.image}
                                alt=""
                                className="h-28 w-full rounded-xl object-cover"
                              />
                              <Heading
                                level={4}
                                className="mt-3 text-base text-ink"
                              >
                                {destination.name}
                              </Heading>
                              <p className="mt-1 text-xs text-muted">
                                {item.time} · {item.duration}
                              </p>
                              <div className="mt-3 flex items-center justify-between">
                                <Button
                                  variant="ghost"
                                  onClick={() => moveNext(item.destinationId)}
                                  className="!px-2 !py-1.5 !text-xs"
                                >
                                  Next day
                                </Button>
                                <Button
                                  variant="ghost"
                                  ariaLabel={`Remove ${destination.name}`}
                                  onClick={() => remove(item.destinationId)}
                                  className="!size-8 !p-0 !text-muted hover:!text-red-700"
                                >
                                  <Icon name="trash" className="size-4" />
                                </Button>
                              </div>
                            </article>
                          )
                        })
                      ) : (
                        <div className="rounded-2xl border border-dashed border-line p-5 text-center text-sm text-muted">
                          Room for another adventure.
                        </div>
                      )}
                    </div>
                  </section>
                )
              })}
            </div>
          ) : (
            <div className="rounded-3xl border border-dashed border-line bg-white px-6 py-24 text-center">
              <Icon name="calendar" className="mx-auto size-10 text-primary" />
              <Heading level={2} className="mt-5 text-3xl text-ink">
                Your days are wide open.
              </Heading>
              <p className="mx-auto mt-3 max-w-md text-muted">
                Save a river, island, trail, or cultural stop and we’ll help
                shape the journey.
              </p>
              <Button onClick={() => navigate("destinations")} className="mt-6">
                Find a place
              </Button>
            </div>
          )}
        </div>
        <aside className="h-fit rounded-3xl bg-primary p-7 text-white shadow-card">
          <Heading level={3} className="text-xl">
            Trip snapshot
          </Heading>
          <div className="mt-6 grid grid-cols-2 gap-3">
            <div className="rounded-2xl bg-white/10 p-4">
              <p className="text-2xl font-extrabold text-accent">286 km</p>
              <p className="mt-1 text-xs text-white/55">Estimated route</p>
            </div>
            <div className="rounded-2xl bg-white/10 p-4">
              <p className="text-2xl font-extrabold text-accent">3 days</p>
              <p className="mt-1 text-xs text-white/55">Easy pace</p>
            </div>
          </div>
          <div className="mt-6 space-y-3 text-sm leading-6 text-white/70">
            <p className="flex gap-2">
              <Icon name="check" className="mt-1 size-4 shrink-0 text-accent" />
              Book local boats a day ahead.
            </p>
            <p className="flex gap-2">
              <Icon name="check" className="mt-1 size-4 shrink-0 text-accent" />
              Keep weather buffers between coastal stops.
            </p>
            <p className="flex gap-2">
              <Icon name="check" className="mt-1 size-4 shrink-0 text-accent" />
              Start road transfers before sunrise.
            </p>
          </div>
          <Button
            variant="light"
            onClick={() => navigate("destinations")}
            className="mt-7 w-full"
          >
            Add more places
          </Button>
        </aside>
      </section>
    </ScreenShell>
  )
}

function SearchScreen({
  navigate,
  openDetails,
  itineraryCount,
  query,
  setQuery,
}: {
  navigate: (screen: ScreenId) => void
  openDetails: (destination: Destination) => void
  itineraryCount: number
  query: string
  setQuery: (value: string) => void
}) {
  const [province, setProvince] = useState("All provinces")
  const [category, setCategory] = useState<"all" | Category>("all")
  const [sort, setSort] = useState("recommended")
  const results = useMemo(() => {
    const needle = query.toLowerCase().trim()
    const matching = destinations.filter((destination) => {
      const haystack =
        `${destination.name} ${destination.municipality} ${destination.province} ${destination.category} ${destination.description}`.toLowerCase()
      return (
        (!needle || haystack.includes(needle)) &&
        (province === "All provinces" || destination.province === province) &&
        (category === "all" || destination.category === category)
      )
    })
    return [...matching].sort((a, b) =>
      sort === "rating"
        ? b.rating - a.rating
        : sort === "name"
          ? a.name.localeCompare(b.name)
          : 0,
    )
  }, [query, province, category, sort])
  const clear = () => {
    setQuery("")
    setProvince("All provinces")
    setCategory("all")
  }
  return (
    <ScreenShell
      active="search"
      itineraryCount={itineraryCount}
      navigate={navigate}
    >
      <section className="bg-primary px-6 py-12">
        <div className="mx-auto max-w-5xl">
          <p className="mb-4 text-center text-xs font-extrabold uppercase tracking-[0.18em] text-accent">
            Search Caraga
          </p>
          <div className="flex items-center gap-3 rounded-3xl bg-white p-3 shadow-xl">
            <Icon name="search" className="ml-2 size-6 shrink-0 text-primary" />
            <Input
              value={query}
              onChange={setQuery}
              ariaLabel="Search all destinations"
              placeholder="Try “island,” “Bislig,” or “nature”"
              className="!border-0 !text-base focus:!ring-0"
            />
            <Button onClick={() => undefined} className="hidden sm:inline-flex">
              Search
            </Button>
          </div>
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-6 py-12">
        <div className="flex flex-col justify-between gap-5 md:flex-row md:items-end">
          <div>
            <p className="text-sm font-bold text-primary">
              {results.length} places found
            </p>
            <Heading level={1} className="mt-2 text-4xl text-ink">
              {query ? <>Results for “{query}”</> : "Explore every possibility"}
            </Heading>
          </div>
          <Select
            value={sort}
            onChange={setSort}
            ariaLabel="Sort search results"
          >
            <option value="recommended">Recommended</option>
            <option value="rating">Highest rated</option>
            <option value="name">Name A–Z</option>
          </Select>
        </div>
        <div className="mt-8">
          <FilterControls
            province={province}
            setProvince={setProvince}
            category={category}
            setCategory={setCategory}
            clear={clear}
          />
        </div>
        <div className="mt-8 space-y-5">
          {results.length ? (
            results.map((destination) => (
              <article
                key={destination.id}
                className="group grid overflow-hidden rounded-3xl border border-line bg-white shadow-card md:grid-cols-[280px_1fr]"
              >
                <img
                  src={destination.image}
                  alt={destination.name}
                  className="h-56 w-full object-cover md:h-full"
                />
                <div className="flex flex-col justify-between gap-6 p-6 md:flex-row md:items-center md:p-8">
                  <div className="max-w-2xl">
                    <div className="flex flex-wrap items-center gap-3">
                      <Badge>{categoryLabels[destination.category]}</Badge>
                      <Rating value={destination.rating} />
                    </div>
                    <Heading level={2} className="mt-4 text-2xl text-ink">
                      {destination.name}
                    </Heading>
                    <p className="mt-2 text-sm text-muted">
                      {destination.municipality}, {destination.province}
                    </p>
                    <p className="mt-4 text-sm leading-6 text-muted">
                      {destination.description}
                    </p>
                  </div>
                  <Button
                    variant="secondary"
                    onClick={() => openDetails(destination)}
                    className="shrink-0"
                  >
                    View destination
                    <Icon name="arrow" className="size-4" />
                  </Button>
                </div>
              </article>
            ))
          ) : (
            <EmptyState clear={clear} />
          )}
        </div>
      </section>
    </ScreenShell>
  )
}

function AboutScreen({
  navigate,
  itineraryCount,
}: {
  navigate: (screen: ScreenId) => void
  itineraryCount: number
}) {
  const values = [
    [
      "Discover responsibly",
      "We favor thoughtful routes, low-impact experiences, and honest travel guidance.",
      "compass" as IconName,
    ],
    [
      "Support local",
      "Every suggested journey makes room for community guides, makers, and family-run stops.",
      "check" as IconName,
    ],
    [
      "Travel with context",
      "We share the history behind each landscape, not just the view from the lookout.",
      "map" as IconName,
    ],
  ]
  const team = [
    ["JL", "Jeah Labastida", "Community storyteller"],
    ["AA", "Ashnea Academia", "Trail & coast editor"],
    ["ER", "Excel Resimo", "Local partnerships"],
    ["EB", "Emmanuel Butal", "Culture & heritage researcher"],
  ]
  return (
    <ScreenShell
      active="about"
      itineraryCount={itineraryCount}
      navigate={navigate}
    >
      <section className="grid min-h-[560px] bg-primary lg:grid-cols-2">
        <div className="flex items-center px-6 py-16 lg:px-16">
          <div className="max-w-xl">
            <Badge dark>About Lakbay Caraga</Badge>
            <Heading
              level={1}
              className="mt-6 text-5xl leading-tight text-white"
            >
              Rooted in Caraga, made for curious travelers.
            </Heading>
            <p className="mt-6 text-lg leading-8 text-white/70">
              We tell the region’s story through water, wilderness, heritage,
              and the people who know every road home.
            </p>
          </div>
        </div>
        <img
          src={destinations[2].image}
          alt="A peaceful lake surrounded by Caraga mountains"
          className="h-full min-h-96 w-full object-cover"
        />
      </section>
      <section className="mx-auto max-w-7xl px-6 py-20">
        <div className="grid gap-12 lg:grid-cols-[0.8fr_1.2fr]">
          <SectionHeading
            eyebrow="The region"
            title="Five provinces. Countless ways to wander."
          />
          <div className="space-y-5 text-lg leading-8 text-muted">
            <p>
              Caraga sits at the northeastern edge of Mindanao, where the
              Pacific meets ancient forests, river systems, and island
              communities.
            </p>
            <p>
              From Agusan’s wetlands and Butuan’s balangay heritage to Surigao’s
              surf and bright-blue springs, its landscapes are connected by
              stories of movement and belonging.
            </p>
          </div>
        </div>
        <div className="mt-16 grid gap-5 md:grid-cols-3">
          {values.map(([title, copy, icon]) => (
            <article
              key={title as string}
              className="rounded-3xl border border-line bg-white p-7 shadow-card"
            >
              <span className="grid size-12 place-items-center rounded-2xl bg-primary-soft text-primary">
                <Icon name={icon as IconName} />
              </span>
              <Heading level={3} className="mt-6 text-xl text-ink">
                {title}
              </Heading>
              <p className="mt-3 text-sm leading-6 text-muted">{copy}</p>
            </article>
          ))}
        </div>
      </section>
      <section className="bg-primary-soft px-6 py-20">
        <div className="mx-auto max-w-7xl">
          <SectionHeading
            eyebrow="Meet the team"
            title="Local voices lead the way."
          />
          <div className="mt-10 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
            {team.map(([initials, name, role], index) => (
              <article
                key={name}
                className="flex items-center gap-5 rounded-3xl bg-white p-6 shadow-card"
              >
                <span
                  className={`grid size-16 shrink-0 place-items-center rounded-full text-lg font-extrabold ${
                    index % 2 === 1
                      ? "bg-accent text-ink"
                      : "bg-primary text-white"
                  }`}
                >
                  {initials}
                </span>
                <div>
                  <Heading level={3} className="text-lg text-ink">
                    {name}
                  </Heading>
                  <p className="mt-1 text-sm text-muted">{role}</p>
                </div>
              </article>
            ))}
          </div>
          <div className="mt-14 flex flex-col items-start justify-between gap-5 rounded-3xl bg-primary p-8 text-white md:flex-row md:items-center">
            <div>
              <Heading level={2} className="text-2xl">
                Ready to find your Caraga story?
              </Heading>
              <p className="mt-2 text-sm text-white/65">
                Start with a place that makes you curious.
              </p>
            </div>
            <Button onClick={() => navigate("destinations")}>
              Explore destinations
            </Button>
          </div>
        </div>
      </section>
    </ScreenShell>
  )
}

function ContactScreen({
  navigate,
  itineraryCount,
}: {
  navigate: (screen: ScreenId) => void
  itineraryCount: number
}) {
  const [form, setForm] = useState({
    name: "",
    email: "",
    interest: "Trip planning",
    message: "",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [submitted, setSubmitted] = useState(false)
  const update = (key: keyof typeof form, value: string) =>
    setForm({ ...form, [key]: value })
  const submit = (event: FormEvent) => {
    event.preventDefault()
    const nextErrors: Record<string, string> = {}
    if (!form.name.trim()) nextErrors.name = "Please tell us your name."
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email))
      nextErrors.email = "Enter a valid email address."
    if (!form.message.trim())
      nextErrors.message = "Add a short message so we can help."
    setErrors(nextErrors)
    if (!Object.keys(nextErrors).length) setSubmitted(true)
  }
  return (
    <ScreenShell
      active="contact"
      itineraryCount={itineraryCount}
      navigate={navigate}
    >
      <section className="mx-auto max-w-7xl px-6 py-16">
        <SectionHeading
          eyebrow="Plan with a local"
          title="Let’s make your Caraga journey count."
          copy="Ask us about routes, responsible travel, or which waterfall belongs on day two."
        />
        <div className="mt-12 grid overflow-hidden rounded-[2rem] bg-white shadow-card lg:grid-cols-[0.8fr_1.2fr]">
          <aside className="relative overflow-hidden bg-primary p-8 text-white md:p-10">
            <div className="absolute inset-0 topographic opacity-10" />
            <div className="relative">
              <Heading level={2} className="text-3xl">
                We’re here to help.
              </Heading>
              <p className="mt-4 leading-7 text-white/65">
                Lakbay Caraga Tourism Desk
                <br />
                Butuan City, Philippines
              </p>
              <div className="mt-10 space-y-6">
                {[
                  ["hello@lakbaycaraga.ph", "mail" as IconName],
                  ["+63 85 555 0148", "phone" as IconName],
                  ["Mon–Sat · 8:00 AM–5:00 PM", "clock" as IconName],
                ].map(([value, icon]) => (
                  <div
                    key={value as string}
                    className="flex items-center gap-3"
                  >
                    <span className="grid size-10 place-items-center rounded-full bg-white/10 text-accent">
                      <Icon name={icon as IconName} className="size-5" />
                    </span>
                    <p className="text-sm font-semibold">{value}</p>
                  </div>
                ))}
              </div>
              <div className="mt-10 flex gap-2">
                <Button
                  variant="ghost"
                  ariaLabel="Instagram"
                  className="!size-11 !p-0 !text-white hover:!bg-white/10"
                >
                  <Icon name="instagram" />
                </Button>
                <Button
                  variant="ghost"
                  ariaLabel="Facebook"
                  className="!size-11 !p-0 !text-white hover:!bg-white/10"
                >
                  <Icon name="facebook" />
                </Button>
              </div>
            </div>
          </aside>
          <div className="p-8 md:p-10">
            {submitted ? (
              <div className="flex min-h-[500px] flex-col items-center justify-center text-center">
                <span className="grid size-16 place-items-center rounded-full bg-accent text-primary">
                  <Icon name="check" className="size-8" />
                </span>
                <Heading level={2} className="mt-6 text-3xl text-ink">
                  Salamat, {form.name.split(" ")[0]}!
                </Heading>
                <p className="mt-3 max-w-md leading-7 text-muted">
                  Your note is on its way. Our local desk will reply within two
                  working days.
                </p>
                <Button
                  variant="secondary"
                  onClick={() => {
                    setSubmitted(false)
                    setForm({
                      name: "",
                      email: "",
                      interest: "Trip planning",
                      message: "",
                    })
                  }}
                  className="mt-7"
                >
                  Send another message
                </Button>
              </div>
            ) : (
              <form onSubmit={submit} noValidate>
                <Heading level={2} className="text-2xl text-ink">
                  Tell us about your trip
                </Heading>
                <div className="mt-7 grid gap-5 sm:grid-cols-2">
                  <label className="text-sm font-bold text-ink">
                    Name
                    <Input
                      value={form.name}
                      onChange={(value) => update("name", value)}
                      ariaLabel="Name"
                      placeholder="Your name"
                      className="mt-2 font-normal"
                    />
                    {errors.name && (
                      <span className="mt-1 block text-xs font-semibold text-red-700">
                        {errors.name}
                      </span>
                    )}
                  </label>
                  <label className="text-sm font-bold text-ink">
                    Email
                    <Input
                      value={form.email}
                      onChange={(value) => update("email", value)}
                      ariaLabel="Email"
                      type="email"
                      placeholder="you@example.com"
                      className="mt-2 font-normal"
                    />
                    {errors.email && (
                      <span className="mt-1 block text-xs font-semibold text-red-700">
                        {errors.email}
                      </span>
                    )}
                  </label>
                </div>
                <label className="mt-5 block text-sm font-bold text-ink">
                  I’m interested in
                  <Select
                    value={form.interest}
                    onChange={(value) => update("interest", value)}
                    ariaLabel="Travel interest"
                    className="mt-2 w-full !rounded-2xl font-normal"
                  >
                    <option>Trip planning</option>
                    <option>Local guides</option>
                    <option>Culture & heritage</option>
                    <option>Responsible travel</option>
                  </Select>
                </label>
                <label className="mt-5 block text-sm font-bold text-ink">
                  Message
                  <textarea
                    value={form.message}
                    onChange={(event) => update("message", event.target.value)}
                    aria-label="Message"
                    placeholder="Where would you like to go?"
                    rows={6}
                    className="mt-2 w-full resize-none rounded-2xl border border-line bg-white px-4 py-3.5 font-normal text-ink outline-none transition placeholder:text-muted focus:border-primary focus:ring-4 focus:ring-primary/10"
                  />
                  {errors.message && (
                    <span className="mt-1 block text-xs font-semibold text-red-700">
                      {errors.message}
                    </span>
                  )}
                </label>
                <Button type="submit" className="mt-6">
                  Send message
                  <Icon name="arrow" className="size-4" />
                </Button>
              </form>
            )}
          </div>
        </div>
      </section>
    </ScreenShell>
  )
}

function AuthLayout({
  mode,
  navigate,
  itineraryCount,
}: {
  mode: "signup" | "login"
  navigate: (screen: ScreenId) => void
  itineraryCount: number
}) {
  const { login } = useAppContext()
  const isSignup = mode === "signup"
  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirm: "",
  })
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [loginError, setLoginError] = useState(false)
  const update = (key: keyof typeof form, value: string) =>
    setForm({ ...form, [key]: value })

  const submit = (event: FormEvent) => {
    event.preventDefault()
    const nextErrors: Record<string, string> = {}
    const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)
    if (isSignup && !form.name.trim())
      nextErrors.name = "Your name is required."
    if (!emailValid) nextErrors.email = "Enter a valid email address."
    if (form.password.length < 8)
      nextErrors.password = "Use at least 8 characters."
    if (isSignup && form.confirm !== form.password)
      nextErrors.confirm = "Passwords must match."
    setErrors(nextErrors)
    if (Object.keys(nextErrors).length) {
      if (!isSignup) setLoginError(true)
      return
    }
    setLoginError(false)
    login(isSignup ? form.name : "Jeah Labastida")
  }

  return (
    <ScreenShell
      active={mode}
      itineraryCount={itineraryCount}
      navigate={navigate}
    >
      <section className="mx-auto max-w-6xl px-6 py-16">
        <div className="grid min-h-[650px] overflow-hidden rounded-[2rem] border border-line bg-white shadow-card lg:grid-cols-2">
          <aside className="relative overflow-hidden bg-primary p-10 text-white md:p-14">
            <div className="absolute inset-0 topographic opacity-15" />
            <div className="relative flex h-full flex-col justify-center">
              <Badge dark>Lakbay Caraga</Badge>
              <Heading level={1} className="mt-6 text-4xl md:text-5xl">
                {isSignup ? "Start your Caraga journey." : "Welcome back."}
              </Heading>
              <p className="mt-5 max-w-md text-lg leading-8 text-white/70">
                {isSignup
                  ? "Create a free account to request bookings and follow their status."
                  : "Log in to book your trips and check on your booking status."}
              </p>
              {isSignup && (
                <div className="mt-9 space-y-4">
                  {[
                    "Request a booking in a few taps",
                    "Track the status of every booking",
                    "Keep your trips in one place",
                  ].map((perk) => (
                    <p
                      key={perk}
                      className="flex items-center gap-3 text-sm font-semibold"
                    >
                      <span className="grid size-7 place-items-center rounded-full bg-accent text-primary">
                        <Icon name="check" className="size-4" />
                      </span>
                      {perk}
                    </p>
                  ))}
                </div>
              )}
            </div>
          </aside>
          <div className="flex items-center p-8 md:p-14">
            <form onSubmit={submit} noValidate className="w-full">
              <Heading level={2} className="text-3xl text-ink">
                {isSignup ? "Create your account" : "Log in"}
              </Heading>
              <p className="mt-3 text-sm leading-6 text-muted">
                {isSignup
                  ? "Plan, request, and keep every Caraga trip together."
                  : "Continue planning where you left off."}
              </p>
              {loginError && (
                <div className="mt-6 rounded-2xl bg-red-50 px-4 py-3 text-sm font-semibold text-red-700">
                  Incorrect email or password.
                </div>
              )}
              <div className="mt-7 space-y-5">
                {isSignup && (
                  <label className="block text-sm font-bold text-ink">
                    Name
                    <Input
                      value={form.name}
                      onChange={(value) => update("name", value)}
                      ariaLabel="Account name"
                      placeholder="Your full name"
                      className="mt-2 font-normal"
                    />
                    {errors.name && (
                      <span className="mt-1 block text-xs font-semibold text-red-700">
                        {errors.name}
                      </span>
                    )}
                  </label>
                )}
                <label className="block text-sm font-bold text-ink">
                  Email
                  <Input
                    type="email"
                    value={form.email}
                    onChange={(value) => update("email", value)}
                    ariaLabel="Account email"
                    placeholder="you@example.com"
                    className="mt-2 font-normal"
                  />
                  {errors.email && (
                    <span className="mt-1 block text-xs font-semibold text-red-700">
                      {errors.email}
                    </span>
                  )}
                </label>
                <div
                  className={isSignup ? "grid gap-5 sm:grid-cols-2" : undefined}
                >
                  <label className="block text-sm font-bold text-ink">
                    Password
                    <Input
                      type="password"
                      value={form.password}
                      onChange={(value) => update("password", value)}
                      ariaLabel="Password"
                      placeholder="At least 8 characters"
                      className="mt-2 font-normal"
                    />
                    {errors.password && (
                      <span className="mt-1 block text-xs font-semibold text-red-700">
                        {errors.password}
                      </span>
                    )}
                  </label>
                  {isSignup && (
                    <label className="block text-sm font-bold text-ink">
                      Confirm password
                      <Input
                        type="password"
                        value={form.confirm}
                        onChange={(value) => update("confirm", value)}
                        ariaLabel="Confirm password"
                        placeholder="Repeat password"
                        className="mt-2 font-normal"
                      />
                      {errors.confirm && (
                        <span className="mt-1 block text-xs font-semibold text-red-700">
                          {errors.confirm}
                        </span>
                      )}
                    </label>
                  )}
                </div>
              </div>
              <Button type="submit" className="mt-7 w-full">
                {isSignup ? "Sign up" : "Log in"}
              </Button>
              <div className="mt-6 flex items-center justify-center gap-2 text-sm text-muted">
                <span>
                  {isSignup
                    ? "Already have an account?"
                    : "New to Lakbay Caraga?"}
                </span>
                <Button
                  variant="ghost"
                  onClick={() => navigate(isSignup ? "login" : "signup")}
                  className="!p-0"
                >
                  {isSignup ? "Log in" : "Create an account"}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </section>
    </ScreenShell>
  )
}

function BookingStatusBadge({ status }: { status: BookingStatus }) {
  const styles: Record<BookingStatus, string> = {
    Pending: "bg-amber-100 text-amber-800",
    Confirmed: "bg-accent text-ink",
    Completed: "bg-primary-soft text-primary",
    Cancelled: "bg-red-50 text-red-700",
  }
  return (
    <span
      className={`rounded-full px-3 py-1 text-xs font-extrabold ${styles[status]}`}
    >
      {status}
    </span>
  )
}

function BookingTracker({ status }: { status: BookingStatus }) {
  if (status === "Cancelled") return null
  const current = status === "Pending" ? 1 : status === "Confirmed" ? 2 : 3
  return (
    <div className="mt-6 grid grid-cols-3">
      {["Requested", "Confirmed", "Completed"].map((step, index) => {
        const filled = index + 1 <= current
        return (
          <div key={step} className="relative text-center">
            {index > 0 && (
              <span
                className={`absolute right-1/2 top-3 h-0.5 w-full ${
                  index + 1 <= current ? "bg-primary" : "bg-line"
                }`}
              />
            )}
            <span
              className={`relative z-10 mx-auto grid size-6 place-items-center rounded-full text-[0.65rem] font-extrabold ${
                filled
                  ? "bg-primary text-white"
                  : "border border-line bg-white text-muted"
              }`}
            >
              {index + 1}
            </span>
            <p
              className={`mt-2 text-xs font-bold ${
                filled ? "text-primary" : "text-muted"
              }`}
            >
              {step}
            </p>
          </div>
        )
      })}
    </div>
  )
}

function BookingsScreen({
  navigate,
  itineraryCount,
  bookings,
  cancelBooking,
  showNotice,
}: {
  navigate: (screen: ScreenId) => void
  itineraryCount: number
  bookings: Booking[]
  cancelBooking: (id: string) => void
  showNotice: boolean
}) {
  const { userName } = useAppContext()
  const [filter, setFilter] = useState<"All" | BookingStatus>("All")
  const filtered =
    filter === "All"
      ? bookings
      : bookings.filter((booking) => booking.status === filter)
  const filters: ("All" | BookingStatus)[] = [
    "All",
    "Pending",
    "Confirmed",
    "Completed",
    "Cancelled",
  ]
  const statusMessages: Record<BookingStatus, string> = {
    Pending: "The tourism desk is reviewing your requested date.",
    Confirmed: "Your visit is confirmed. Check your notes before the trip.",
    Completed: "Journey complete—salamat for traveling with care.",
    Cancelled: "This request has been cancelled.",
  }

  return (
    <ScreenShell
      active="bookings"
      itineraryCount={itineraryCount}
      navigate={navigate}
    >
      <section className="bg-primary px-6 py-14 text-white">
        <div className="mx-auto flex max-w-7xl flex-col justify-between gap-7 md:flex-row md:items-end">
          <div>
            <p className="text-xs font-extrabold uppercase tracking-[0.18em] text-accent">
              Your trips
            </p>
            <Heading level={1} className="mt-3 text-5xl">
              My bookings
            </Heading>
            <p className="mt-3 text-white/65">Signed in as {userName}.</p>
          </div>
          <Button variant="light" onClick={() => navigate("destinations")}>
            Book another place
            <Icon name="arrow" className="size-4" />
          </Button>
        </div>
      </section>
      <section className="mx-auto max-w-7xl px-6 py-12">
        <div className="flex flex-wrap gap-2">
          {filters.map((item) => {
            const count =
              item === "All"
                ? bookings.length
                : bookings.filter((booking) => booking.status === item).length
            return (
              <Button
                key={item}
                variant={filter === item ? "secondary" : "light"}
                onClick={() => setFilter(item)}
                className="!py-2.5"
              >
                {item}
                <span
                  className={`grid size-5 place-items-center rounded-full text-[0.65rem] ${
                    filter === item
                      ? "bg-white/15 text-white"
                      : "bg-primary-soft text-primary"
                  }`}
                >
                  {count}
                </span>
              </Button>
            )
          })}
        </div>
        {showNotice && (
          <div className="mt-6 flex items-start gap-3 rounded-2xl bg-primary-soft p-4 text-sm font-semibold text-primary">
            <Icon name="check" className="mt-0.5 size-5 shrink-0" />
            Booking requested! It starts as pending and will be confirmed by the
            tourism desk.
          </div>
        )}
        <div className="mt-8 space-y-6">
          {filtered.length ? (
            filtered.map((booking) => {
              const destination =
                destinations.find(
                  (item) => item.id === booking.destinationId,
                ) ?? destinations[0]
              return (
                <article
                  key={booking.id}
                  className="grid overflow-hidden rounded-3xl border border-line bg-white shadow-card lg:grid-cols-[300px_1fr]"
                >
                  <img
                    src={destination.image}
                    alt={destination.name}
                    className="h-64 w-full object-cover lg:h-full"
                  />
                  <div className="p-6 md:p-8">
                    <div className="flex flex-col justify-between gap-4 sm:flex-row sm:items-start">
                      <div>
                        <p className="text-xs font-extrabold uppercase tracking-[0.16em] text-primary">
                          {booking.id}
                        </p>
                        <Heading level={2} className="mt-2 text-2xl text-ink">
                          {destination.name}
                        </Heading>
                        <p className="mt-2 text-sm text-muted">
                          {booking.date} · {booking.guests}{" "}
                          {booking.guests === 1 ? "guest" : "guests"} ·
                          Requested {booking.requested}
                        </p>
                      </div>
                      <BookingStatusBadge status={booking.status} />
                    </div>
                    {booking.note && (
                      <p className="mt-5 rounded-2xl bg-sand px-4 py-3 text-sm italic text-muted">
                        “{booking.note}”
                      </p>
                    )}
                    <BookingTracker status={booking.status} />
                    <div className="mt-6 flex flex-col justify-between gap-3 border-t border-line pt-5 sm:flex-row sm:items-center">
                      <p className="text-sm text-muted">
                        {statusMessages[booking.status]}
                      </p>
                      {(booking.status === "Pending" ||
                        booking.status === "Confirmed") && (
                        <Button
                          variant="ghost"
                          onClick={() => cancelBooking(booking.id)}
                          className="!text-red-700 hover:!bg-red-50"
                        >
                          Cancel booking
                        </Button>
                      )}
                    </div>
                  </div>
                </article>
              )
            })
          ) : (
            <div className="rounded-3xl border border-dashed border-line bg-white px-6 py-20 text-center">
              <Icon name="calendar" className="mx-auto size-10 text-primary" />
              <Heading level={2} className="mt-5 text-3xl text-ink">
                No bookings yet.
              </Heading>
              <p className="mt-3 text-muted">
                Pick a place and request your first Caraga visit.
              </p>
              <Button onClick={() => navigate("destinations")} className="mt-6">
                Find a place
              </Button>
            </div>
          )}
        </div>
      </section>
    </ScreenShell>
  )
}

function parseHash(): { screen: ScreenId destinationId?: string } {
  const path = window.location.hash.replace(/^#\//, "")
  if (path.startsWith("details/"))
    return { screen: "details", destinationId: path.split("/")[1] }
  const valid: ScreenId[] = [
    "home",
    "destinations",
    "map",
    "itinerary",
    "search",
    "about",
    "contact",
    "signup",
    "login",
    "bookings",
  ]
  return {
    screen: valid.includes(path as ScreenId) ? path as ScreenId : "home",
  }
}

export default function App() {
  const initial = parseHash()
  const [screen, setScreen] = useState<ScreenId>(initial.screen)
  const [selectedDestination, setSelectedDestination] = useState(
    destinations.find((item) => item.id === initial.destinationId) ??
      destinations[0],
  )
  const [searchQuery, setSearchQuery] = useState("")
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [userName, setUserName] = useState("Jeah Labastida")
  const [bookingNotice, setBookingNotice] = useState(false)
  const [bookings, setBookings] = useState<Booking[]>([
    {
      id: "LC-3F9A2B",
      destinationId: "enchanted-river",
      status: "Pending",
      date: "May 16, 2026",
      guests: 2,
      requested: "April 28, 2026",
      note: "We would love an early morning entry.",
    },
    {
      id: "LC-8D4C1E",
      destinationId: "siargao-island",
      status: "Confirmed",
      date: "May 18, 2026",
      guests: 2,
      requested: "April 21, 2026",
      note: "First-time surfers.",
    },
    {
      id: "LC-6B7E4A",
      destinationId: "tinuy-an-falls",
      status: "Completed",
      date: "March 8, 2026",
      guests: 4,
      requested: "February 12, 2026",
    },
    {
      id: "LC-1A5D8F",
      destinationId: "britania-islands",
      status: "Cancelled",
      date: "February 14, 2026",
      guests: 3,
      requested: "January 30, 2026",
    },
  ])
  const [itinerary, setItinerary] = useState<ItineraryItem[]>([
    {
      destinationId: "enchanted-river",
      day: 1,
      time: "8:00 AM",
      duration: "3 hrs",
    },
    {
      destinationId: "tinuy-an-falls",
      day: 2,
      time: "7:30 AM",
      duration: "4 hrs",
    },
    {
      destinationId: "siargao-island",
      day: 3,
      time: "9:00 AM",
      duration: "Full day",
    },
  ])

  useEffect(() => {
    const sync = () => {
      const next = parseHash()
      setScreen(next.screen)
      if (next.destinationId) {
        const found = destinations.find(
          (item) => item.id === next.destinationId,
        )
        if (found) setSelectedDestination(found)
      }
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
    window.addEventListener("hashchange", sync)
    if (!window.location.hash) window.history.replaceState(null, "", "#/home")
    return () => window.removeEventListener("hashchange", sync)
  }, [])

  const navigate = (next: ScreenId) => {
    const hash =
      next === "details"
        ? `#/details/${selectedDestination.id}`
        : screenPaths[(next as Exclude<ScreenId, "details">)]
    if (window.location.hash === hash) {
      setScreen(next)
      window.scrollTo({ top: 0, behavior: "smooth" })
    } else {
      window.location.hash = hash
    }
  }

  const openDetails = (destination: Destination) => {
    setSelectedDestination(destination)
    window.location.hash = `#/details/${destination.id}`
  }

  const addToItinerary = (destination: Destination) => {
    if (!itinerary.some((item) => item.destinationId === destination.id)) {
      const counts = [1, 2, 3].map(
        (day) => itinerary.filter((item) => item.day === day).length,
      )
      const day = counts.indexOf(Math.min(...counts)) + 1
      setItinerary([
        ...itinerary,
        {
          destinationId: destination.id,
          day,
          time: "10:00 AM",
          duration: "3 hrs",
        },
      ])
    }
    navigate("itinerary")
  }

  const login = (name?: string) => {
    setIsLoggedIn(true)
    if (name?.trim()) setUserName(name.trim())
    navigate("home")
  }

  const logout = () => {
    setIsLoggedIn(false)
    setBookingNotice(false)
    navigate("home")
  }

  const requestBooking = (
    destination: Destination,
    date: string,
    guests: number,
    note: string,
  ) => {
    const formattedDate = new Date(`${date}T12:00:00`).toLocaleDateString(
      "en-US",
      { month: "long", day: "numeric", year: "numeric" },
    )
    const id = `LC-${(bookings.length + 5).toString(16).toUpperCase()}A7C2D`
    setBookings([
      {
        id,
        destinationId: destination.id,
        status: "Pending",
        date: formattedDate,
        guests: Math.min(20, Math.max(1, guests || 1)),
        requested: "today",
        note: note.trim() || undefined,
      },
      ...bookings,
    ])
    setBookingNotice(true)
    navigate("bookings")
  }

  const cancelBooking = (id: string) =>
    setBookings(
      bookings.map((booking) =>
        booking.id === id ? { ...booking, status: "Cancelled" } : booking,
      ),
    )

  const shared = { navigate, itineraryCount: itinerary.length }
  return (
    <AppContext.Provider
      value={{
        isLoggedIn,
        userName,
        navigate,
        login,
        logout,
        requestBooking,
      }}
    >
      <>
        {screen === "home" && (
          <HomeScreen
            {...shared}
            openDetails={openDetails}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
          />
        )}
        {screen === "destinations" && (
          <DestinationsScreen {...shared} openDetails={openDetails} />
        )}
        {screen === "details" && (
          <DetailsScreen
            {...shared}
            destination={selectedDestination}
            addToItinerary={addToItinerary}
            isSaved={itinerary.some(
              (item) => item.destinationId === selectedDestination.id,
            )}
          />
        )}
        {screen === "map" && (
          <MapScreen {...shared} openDetails={openDetails} />
        )}
        {screen === "itinerary" && (
          <ItineraryScreen
            navigate={navigate}
            itinerary={itinerary}
            setItinerary={setItinerary}
          />
        )}
        {screen === "search" && (
          <SearchScreen
            {...shared}
            openDetails={openDetails}
            query={searchQuery}
            setQuery={setSearchQuery}
          />
        )}
        {screen === "about" && <AboutScreen {...shared} />}
        {screen === "contact" && <ContactScreen {...shared} />}
        {screen === "signup" && <AuthLayout mode="signup" {...shared} />}
        {screen === "login" && <AuthLayout mode="login" {...shared} />}
        {screen === "bookings" &&
          (isLoggedIn ? (
            <BookingsScreen
              {...shared}
              bookings={bookings}
              cancelBooking={cancelBooking}
              showNotice={bookingNotice}
            />
          ) : (
            <AuthLayout mode="login" {...shared} />
          ))}
      </>
    </AppContext.Provider>
  )
}
