# Lakbay Caraga Clickable Prototype — Implementation Plan

## 1. Goal and confirmed interpretation

Build a polished, desktop-first clickable tourism prototype in the existing React 19 + Vite + Tailwind CSS v4 app.

- Treat the eight requested Figma “frames” as eight full-content application screens shown one at a time, as confirmed by the user.
- Design each screen around a 1440 × 1024 desktop composition, while allowing sensible reflow for narrower preview widths so content remains usable.
- Preserve the requested flow order and screen labels internally:
  1. `01 Home`
  2. `02 Destinations`
  3. `03 Destination Details`
  4. `04 Map`
  5. `05 Itinerary`
  6. `06 Search Results`
  7. `07 About`
  8. `08 Contact`
- Deliver a front-end prototype only: realistic static tourism data plus client-side interactions, with no backend, authentication, booking, or persistence beyond the active browser session.

## 2. Current repository constraints

- The repository is a minimal scaffold: `src/App.tsx` is empty, `src/index.css` only imports Tailwind, and there is no component library, router, icon package, or existing design system.
- Keep dependencies unchanged. Implement a lightweight client-side screen router with React state and the History API rather than adding a routing package.
- Do not start another development server; the Figma Make Vite server is already supervised.
- Follow the repository’s React/Tailwind structure and default-export component requirement.

## 3. Visual system

Define a small local design system in `src/index.css` using semantic Tailwind v4 theme variables and reusable component classes:

- Primary dark teal: `#0B5563`
- Supporting deep teal and soft teal tints for depth and active states
- Yellow-green accent in the chartreuse/lime family for primary actions and selected controls
- Warm off-white page background, white cards, charcoal body copy, and muted gray-green supporting text
- Clean sans-serif typography using the public Google Font **Manrope** (CSS import placed after the Tailwind import ordering requirements are handled correctly), with bold, compact display headings and highly legible body text
- Rounded cards, pill controls, subtle borders, soft shadows, generous whitespace, and restrained decorative contour/topographic motifs
- A consistent 80px-style navigation rhythm, max-width content container, and desktop grid proportions across all screens
- Visible focus rings, high-contrast action text, descriptive image alt text, and motion reduction support

Create local primitives in `App.tsx` (or a focused `src/components.tsx` only if `App.tsx` becomes unwieldy):

- `Button`, `NavLink`, `Icon`, `Input`, `Select`, `SectionHeading`, `Badge`, `Rating`, `DestinationCard`, and `ScreenShell`
- Use inline SVG through the shared `Icon` component for search, map pin, star, calendar, arrow, social, contact, and planner symbols; do not introduce an icon dependency.

Photography will use selected Unsplash image URLs already researched for Philippine tropical islands, jungle waterfalls, rivers, lakes, and mountains. Use intentional crops and overlays, and include photographer attribution in a subtle footer/credits treatment.

## 4. Navigation and state architecture

### Screen router

- Model screens with a typed `ScreenId` union: `home`, `destinations`, `details`, `map`, `itinerary`, `search`, `about`, `contact`.
- Keep the active screen in React state and synchronize it with clean hash routes such as `#/destinations` and `#/details/enchanted-river`.
- On navigation: update browser history, reset scroll to the top, update the active nav item, and animate the incoming screen.
- Handle `popstate`/hash changes so browser Back and Forward work.
- Use a directional transition matching the requested Smart Animate / Move In feel: opacity plus a short horizontal translate, with a reduced-motion fallback.

### Shared state

- Store a single canonical destination dataset with: id, name, province, municipality, category, rating, image, short description, long description, location, best time, activities, gallery images, and approximate map coordinates.
- Include at minimum:
  - Enchanted River — Hinatuan, Surigao del Sur — nature
  - Tinuy-an Falls — Bislig, Surigao del Sur — falls
  - Lake Mainit — Agusan del Norte / Surigao del Norte — nature
  - Siargao Island — Surigao del Norte — beach
  - Britania Group of Islands — San Agustin, Surigao del Sur — beach
  - Mount Hilong-hilong — Agusan del Norte — nature
- Maintain:
  - selected destination
  - destination/search query
  - province and category filters
  - sort option
  - itinerary items grouped by day
  - selected map pin
  - contact form values and submitted state
- Seed the itinerary with two realistic saved places so the planner is never empty; “Add to Itinerary” adds the currently selected destination once and then navigates to the planner.

## 5. Shared navigation

Every screen receives the same sticky dark-teal navigation bar:

- Lakbay Caraga wordmark and simple sun/wave mark; clicking it returns to Home.
- Links: Home, Destinations, Map, Itinerary, About, Contact.
- Search icon/control that opens Search Results with focus on the query field.
- Active page indicator and saved itinerary count badge.
- Destination Details and Search Results treat Destinations as the active parent section.
- All controls remain keyboard accessible.

## 6. Screen-by-screen content and behavior

### 01 Home

- Full-width photographic hero with a dark teal gradient overlay, compact “Discover Northeastern Mindanao” eyebrow, strong tagline, supporting copy, and destination search field.
- Search submission navigates to Search Results using the entered query.
- “Explore Now” navigates to Destinations.
- Add a compact trust/metadata row such as provinces, curated places, and island experiences.
- “Featured escapes” section with three large destination cards (Siargao Island, Enchanted River, Tinuy-an Falls); each opens Details for that place.
- Add a smaller editorial strip promoting local culture and responsible travel so the screen feels complete rather than ending after one card row.

### 02 Destinations List

- Intro heading and result count.
- Filter row with province dropdown, category pills for All/Beach/Falls/Nature/Cultural, and a compact clear-filters action.
- Responsive 3-column destination grid with image, category, destination name, municipality/province, rating, and brief descriptor.
- Filters update the result count and cards immediately.
- Every card opens Destination Details for its destination.
- Include a designed empty-filter state with a clear-filters action, although seeded combinations should generally produce results.

### 03 Destination Details

- Use Enchanted River as the default detail opened from direct navigation; cards update the selected destination first.
- Large cinematic image area with breadcrumb, title, location, rating, and floating summary card.
- Main description, best time to visit, location, and activity chips.
- “Add to Itinerary” primary CTA; after adding, navigate to Itinerary and focus/highlight the added stop.
- Three-image gallery with varied spans and image captions.
- Include concise travel notes (opening window, suggested duration, responsible travel reminder) to make the frame complete.

### 04 Map

- Create an interactive-style illustrated Caraga map as an accessible inline SVG panel; this is a prototype visualization rather than a geographic/GIS integration.
- Plot one labeled/clickable pin per destination using normalized coordinates.
- Right-side list shows all places with category and province; selecting either a pin or list row highlights both and updates a preview card.
- Preview card includes image, rating, locality, and “View details,” which opens Destination Details.
- Add a small legend for beach, falls, nature, and cultural categories.

### 05 Itinerary Planner

- Header summary showing trip title, day count, saved stop count, and a lightweight “May 16–19” sample date range.
- Day-by-day planner with Day 1 through Day 3 columns/timeline cards.
- Each stop shows sequence, destination thumbnail, locality, suggested visit window, and duration.
- Allow moving a stop to the next day and removing it; keep the interaction deterministic and compact rather than implementing drag and drop.
- Include an “Add more places” action back to Destinations and a right-side trip summary with route estimate and planning tips.
- Show a polished empty state if every item is removed.

### 06 Search Results

- Prominent search input prefilled from the Home query or defaulted to “island.”
- Result count and active query summary.
- Sorting: Recommended, Rating, Name.
- Province and category filters reuse the Destinations filtering model.
- Results appear in a list/grid hybrid with image, matching metadata, rating, short description, and “View destination.”
- Search works against destination name, municipality, province, category, and description; a no-results state offers to clear search and filters.

### 07 About

- Hero split with Caraga landscape photography and “Rooted in Caraga, made for curious travelers.”
- Story section explaining the region and its five provinces plus Butuan City in concise, realistic copy.
- Mission/value cards: discover responsibly, support local communities, travel with context.
- “Meet the local guides” team section with three fictional team members, role labels, and consistent portrait treatments or initial-based editorial avatars.
- Closing CTA links to Destinations.

### 08 Contact

- Friendly introduction and contact details for a fictional Butuan-based tourism information desk.
- Full contact form with name, email, travel interest, and message.
- Required-field and email-format validation on submit; display inline errors without leaving the screen.
- Successful submission switches the form to a clear confirmation panel and provides a “Send another message” reset.
- Email, phone, office hours, and social links appear in a dark teal information panel.
- Social actions are prototype-safe buttons/links and do not claim live external accounts.

## 7. Interaction map

- Logo → Home from every screen.
- Main nav → matching Home, Destinations, Map, Itinerary, About, or Contact screen.
- Home “Explore Now” → Destinations.
- Home hero search → Search Results with query.
- Destination cards and map “View details” → Destination Details with matching content.
- Details “Add to Itinerary” → add once, then Itinerary.
- Search icon → Search Results.
- Itinerary “Add more places” → Destinations.
- About CTA → Destinations.
- Contact submit → validated confirmation state.
- All screen changes use the same short move-in transition; card hover/focus and pin selection use smaller scale/color transitions.

## 8. File changes

- `src/App.tsx`
  - Build the full dataset, shared primitives, router/state management, navigation, all eight screen components, and prototype interactions.
  - Keep components logically grouped and typed; if the file becomes difficult to scan, split only the destination data and screen components into `src/data/destinations.ts` and `src/components/` while retaining `App.tsx` as the default-export application shell.
- `src/index.css`
  - Add the font import/wiring, Tailwind v4 semantic theme variables, global base styles, reusable texture/map/transition helpers, scrollbar treatment, and reduced-motion behavior.
- No package changes are expected.

## 9. Verification

Because this is a broad multi-screen implementation:

1. Run `pnpm build` and fix all TypeScript, JSX, and bundling failures.
2. Run `pnpm format` using the repository’s prescribed formatter; then rerun `pnpm build` if formatting changed source.
3. Confirm every one of the eight routes renders non-empty content and the shared nav is present.
4. Exercise the required prototype paths:
   - logo and all six nav links
   - Home Explore Now
   - Home search to Search Results
   - cards to Details
   - Details add to Itinerary without duplicates
   - map pin/list synchronization and details link
   - destination/search filters, sorting, clear, and empty states
   - itinerary move/remove/add-more actions
   - contact validation, success, and reset
   - browser Back/Forward behavior
5. Check the desktop preview at the intended 1440 × 1024 composition and spot-check a narrower viewport for overflow and readable reflow.
6. Verify keyboard focus visibility, semantic labels, image alt text, and reduced-motion behavior.

## 10. Out of scope

- Actual Figma canvas frame creation or editable Figma prototype nodes
- Real map tiles, geolocation, routing, or exact GIS boundaries
- Backend contact delivery, authentication, bookings, analytics, or server persistence
- Guaranteed photographic documentation of the exact named locations; Unsplash imagery will be contextually representative and clearly used as prototype content
